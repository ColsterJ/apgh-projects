class MadLib
    def initialize 
        @mad_words = []
        @mad_prompts = []
        @template = ""
    end

    def replace
        output = @template
        (0..@mad_prompts.length-1).each do |index|
            output = output.sub("{#{@mad_prompts[index]}}", @mad_words[index])
        end
        return output
    end

    def process_template text
        @template = text
        find_prompts
    end

    def find_prompts #hard part! BREXIT HARD
        # go through template and find all the {prompts}
        # put those {prompts} into @mad_prompts
        found_word = false
        temp_word = ""
        @mad_prompts = []

        @template.each_char do |i|

            if found_word == true && i != "}"
                temp_word += i
            end

            if found_word == true && i == "}"
                @mad_prompts << temp_word
                temp_word = ""
                found_word = false
            end

            if found_word == false && i == "{"
                found_word = true
            end
        end

        # position = 0
        # counter = 0

        # problem with regex approah was that match returns multiple matches instead of just one. maybe make or find a match_first? 

        # while position < @template.length-1
        #     @template.match(/{\w+}/, position) do |m|
        #         @mad_prompts[counter] = m[0]
        #         position = @template.index(m[0]) + m[0].length
        #         counter += 1
        #     end
        # end

        @mad_prompts
    end

    def get_prompts
        return @mad_prompts
    end

    def fill_words arr
        @mad_words = arr
    end
end
